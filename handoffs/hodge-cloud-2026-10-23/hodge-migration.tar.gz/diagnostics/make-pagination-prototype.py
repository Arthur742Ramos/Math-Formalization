from pathlib import Path
p=Path('/workspace/hodge-verso-diagnosis/src/verso-html/VersoHtmlMain.lean')
# Always start from the authenticated upstream source; source/proofs are untouched.
import subprocess
s=subprocess.check_output(['git','show','9f8096e40b31715b1d8d5997f15a0bd832f7e37d:src/verso-html/VersoHtmlMain.lean'],cwd=p.parents[2]).decode()
s=s.replace('  outputDir : System.FilePath\n','  outputDir : System.FilePath\n  declarationsFile : Option System.FilePath := none\n',1)
s=s.replace('  | [i, o] => pure { inputDir := i, outputDir := o }','  | [i, o] => pure { inputDir := i, outputDir := o }\n  | [i, o, d] => pure { inputDir := i, outputDir := o, declarationsFile := some d }',1)
s=s.replace('(mod : LitMod) : EmitM Unit := do','(mod : LitMod) (selected : Array Name := #[]) : EmitM Unit := do',1)
a=s.index('  IO.FS.writeFile (outFile / "index.html")');b=s.index('\ndef emitDir',a)
s=s[:a]+'''  if selected.isEmpty then
    IO.FS.writeFile (outFile / "index.html") <| "<!DOCTYPE html>\\n" ++ contents.asString
  else
    -- Prototype only: all source commands remain on whole-command pages.
    -- The original compared entrypoint contains every selected declaration.
    let cap := 4 * 1024 * 1024
    let fileCap := 8 * 1024 * 1024
    let mut chunks : Array (Array Html) := #[]
    let mut pending : Array Html := #[]
    let mut pendingBytes := 0
    let mut selectedHtml : Array Html := #[]
    let mut found : Array Name := #[]
    for item in mod.contents, result in results do
      let h := result.1
      let bytes := h.asString.utf8ByteSize
      if bytes > cap then
        throw <| IO.userError "one source command exceeds pagination cap"
      if pendingBytes + bytes > cap && !pending.isEmpty then
        chunks := chunks.push pending
        pending := #[]
        pendingBytes := 0
      pending := pending.push h
      pendingBytes := pendingBytes + bytes
      if item.defines.any selected.contains then
        selectedHtml := selectedHtml.push h
        found := found ++ item.defines.filter selected.contains
    if !pending.isEmpty then chunks := chunks.push pending
    if selected.any (fun n => found.count n != 1) then
      throw <| IO.userError "selected declaration missing or duplicated"
    let modulePath := "/".intercalate (components.map toString)
    let links : Array Html := chunks.mapIdx fun i _ =>
      {{<a href={{s!"{modulePath}/source-{i + 1}.html"}}>Source page {{toString (i + 1)}}</a>}}
    let navigation : Html := {{<nav aria-label="Complete source">{{links}}</nav>}}
    let mut pageNames : Array String := #[]
    for chunk in chunks, i in [0:chunks.size] do
      let name := s!"source-{i + 1}.html"
      let text := "<!DOCTYPE html>\\n" ++
        (page (toString mod.name) siteRoot headContents mod.name root htmlId?
          (navigation ++ .seq chunk)).asString
      if text.utf8ByteSize > fileCap then
        throw <| IO.userError "source page exceeds unchanged file cap"
      IO.FS.writeFile (outFile / name) text
      pageNames := pageNames.push name
    let selectedText := "<!DOCTYPE html>\\n" ++
      (page (toString mod.name) siteRoot headContents mod.name root htmlId?
        (.seq selectedHtml)).asString
    if selectedText.utf8ByteSize > fileCap then
      throw <| IO.userError "compared declaration surface exceeds unchanged file cap"
    IO.FS.writeFile (outFile / "index.html") selectedText
    IO.FS.writeFile (outFile / "source-pages.json") <| Json.compress <| Json.mkObj [
      ("schema_version", toJson (1 : Nat)),
      ("module", toJson mod.name.toString),
      ("source_commands", toJson mod.contents.size),
      ("selected_declarations", toJson (selected.map toString)),
      ("pages", toJson pageNames)]
''' + s[b:]
s=s.replace('def emitDir (outDir : System.FilePath) (dir : Dir) : EmitM Unit := do','def emitDir (outDir : System.FilePath) (dir : Dir) (selected : Array Name := #[]) : EmitM Unit := do')
s=s.replace('        emitMod root outDir m','        emitMod root outDir m selected',1)
s=s.replace('  withLogger fun logger => do\n    IO.FS.createDirAll config.outputDir','''  let selected ← match config.declarationsFile with
    | none => pure #[]
    | some f => do
      let j ← IO.ofExcept <| Json.parse (← IO.FS.readFile f)
      let names ← IO.ofExcept <| fromJson? (α := Array String) j
      if names.isEmpty || names.toList.eraseDups.length != names.size then
        throw <| IO.userError "declaration list must be nonempty and unique"
      pure (names.map String.toName)
  withLogger fun logger => do
    IO.FS.createDirAll config.outputDir''',1)
s=s.replace('emitDir config.outputDir dir |>.run ctx','emitDir config.outputDir dir selected |>.run ctx',1)
p.write_text(s)
