from pathlib import Path
import re,json

def term(s,i):
 while s[i].isspace():i+=1
 start=i
 if s[i]=='(':
  depth=1;i+=1
  while depth:
   depth+=(s[i]=='(')-(s[i]==')');i+=1
 else:
  while i<len(s) and not s[i].isspace() and s[i] not in ',)]:':i+=1
 return s[start:i],i

def replace(s,prefix,kind):
 out=[];i=0;count=0
 while (a:=s.find(prefix,i))>=0:
  out.append(s[i:a]);v,b=term(s,a+len(prefix))
  if kind=='component':
   if s[b:b+4]!= ').X ':out.append(s[a:b]);i=b;continue
   w,b=term(s,b+4);out.append(f'(component K {v} {w})')
  elif kind=='totalDifferential':
   w,b=term(s,b)
   if s[b:b+5]!= ').hom':out.append(s[a:b]);i=b;continue
   b+=5;out.append(f'(totalDifferential K {v} {w})')
  else:out.append(f'(totalObject K {v})')
  i=b;count+=1
 out.append(s[i:]);return ''.join(out),count
p=Path('/workspace/hodge-render-local');s=(p/'baseline-HodgeChallenge.lean').read_text();counts={}
for prefix,kind in [('((total K).d ','totalDifferential'),('(K.X ','component'),('(total K).X ','totalObject')]:s,counts[kind]=replace(s,prefix,kind)
mark='end AlgebraicHodgePilot\n'
alias='''abbrev component {k : Type} [Field k] (K : Bicomplex k) (p q : ℤ) := (K.X p).X q
abbrev totalObject {k : Type} [Field k] (K : Bicomplex k) (n : ℤ) := (total K).X n
abbrev totalDifferential {k : Type} [Field k] (K : Bicomplex k) (n m : ℤ) := ((total K).d n m).hom
'''
s=s.replace(mark,alias+mark,1);(p/'alias-HodgeChallenge.lean').write_text(s);print(counts)
