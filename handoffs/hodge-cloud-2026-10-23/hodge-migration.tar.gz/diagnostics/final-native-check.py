from pathlib import Path
import sys,json,os,hashlib,tarfile
root=Path('/workspace/Math-Formalization');p=Path('/workspace/hodge-render-local')
sys.path.insert(0,'/workspace/hodge-preparation-tools-current')
from scripts import render_challenge as r
# Explicit prototype composition only: existing sanitizer/limits plus inert
# proposed navigation runtime, NOT an unmodified canonical pipeline execution.
r.VERSO_RUNTIME=(root/'rendering-proposals/hodge-pagination/proposed-runtime.js').read_text()
source=p/'baseline-HodgeChallenge.lean'
config=json.loads((root/'algebraic-hodge/ddbar-pilot/comparator.json').read_text())
lean=Path('/workspace/palomar-tools/elan/toolchains/leanprover--lean4---v4.35.0-rc2/bin/lean')
metadata={'schema_version':1,'imports':list(r.source_header(source,lean=lean,environment=os.environ.copy()).imports),
 'module_doc':r.extract_module_doc(source.read_text()),'declarations':config['theorem_names']+config['definition_names']}
(p/'native-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
out=p/'pagination-native-final';out.mkdir()
r.sanitize_bundle(p/'pagination-routed-v3',out,challenge_module='HodgeChallenge',metadata=metadata)
files,tree=r.artifact_manifest(out)
receipt={'scope':'Native diagnostic composition only; NOT canonical execution, protected acceptance, sandbox replay, core-notation audit or browser inspection',
 'source_challenge_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'source_origin_commit':'7eec3b8c5864af8571fb9c0be3a5f8ce281d7cbb',
 'sanitizer_function_and_limits_origin':'07a02bae1e85c75ae349d0e75195162d16d41e21',
 'proposed_runtime_sha256':hashlib.sha256((root/'rendering-proposals/hodge-pagination/proposed-runtime.js').read_bytes()).hexdigest(),
 'metadata_fixture':'Native schema1 fixture uses compiler-read actual imports, original module doc, actual comparator names; no core notation audit is supplied or claimed',
 'native_check_outcome':'sanitizer and artifact limits accepted prototype output','source_pages':4,
 'total_bytes':sum(f['bytes']for f in files),'largest_file_bytes':max(f['bytes']for f in files),'files':files,'artifact_tree_sha256':tree}
(p/'pagination-native-final-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
with tarfile.open(p/'pagination-native-final.tar.gz','w:gz')as tar:
 for f in sorted(out.rglob('*')):
  if f.is_file():tar.add(f,arcname=f.relative_to(out),recursive=False)
print(json.dumps({k:receipt[k] for k in ['scope','native_check_outcome','total_bytes','largest_file_bytes']}))
