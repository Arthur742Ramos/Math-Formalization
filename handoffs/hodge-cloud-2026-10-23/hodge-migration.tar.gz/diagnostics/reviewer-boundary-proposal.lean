module

-- Probe-only import of the existing predecessor module. Integrating the two
-- declarations below needs no new import in BoundaryLeading or Challenge.
public import ColumnComponents

@[expose] public section
set_option backward.isDefEq.respectTransparency false
open CategoryTheory

namespace AlgebraicHodgePilot.Column

/-- A visible linear-algebra step: an invertible signed summand is killed
when its sum with a killed vector is zero. -/
theorem reviewer_linear_signed_sum {k : Type} [Field k]
    {A B : Type} [AddCommGroup A] [Module k A] [AddCommGroup B] [Module k B]
    (f : A →ₗ[k] B) (c z : A) (ε : ℤˣ)
    (hsum : (0 : A) = c + ε • z) (hc : f c = 0) : f z = 0 :=
  (smul_eq_zero_iff_eq ε).mp
    (show ε • f z = 0 from by
      simpa only [map_zero, map_add, Units.smul_def, map_zsmul, hc, zero_add]
        using (congrArg f hsum).symm)

variable {k : Type} [Field k] (K : Bicomplex k)

-- Same hypothesis and conclusion as boundary_leading_exact, with all witness
-- construction and equalities visible. This probe does not replace the theorem.
theorem reviewer_boundary_leading_exact (p q n : ℤ) (hn : p + q = n)
    (hdd : ImageKernel K (p - 1) q) (u : (total K).X (n - 1))
    (hu : ((total K).d (n - 1) n).hom u ∈ filtration K p n) :
    ∃ b : (K.X p).X (q - 1), incomingVertical K p q b =
      (projection K p q n).hom (((total K).d (n - 1) n).hom u) :=
  let a := (projection K (p - 1) q (n - 1)).hom u
  let b := (projection K p (q - 1) (n - 1)).hom u
  let c := (projection K (p - 1 - 1) (q + 1) (n - 1)).hom u
  have hd : (projection K p q n).hom (((total K).d (n - 1) n).hom u) =
      ((K.d (p - 1) p).f q).hom a + p.negOnePow • incomingVertical K p q b := by
    have h := d_projection_apply K p q (n - 1) (by lia -abstractProof) u
    rw [show n - 1 + 1 = n by lia -abstractProof] at h
    exact h
  have hlo : (projection K (p - 1) (q + 1) n).hom
      (((total K).d (n - 1) n).hom u) = 0 :=
    projection_kills_next K (p - 1) (q + 1) n
      (show ((total K).d (n - 1) n).hom u ∈ filtration K (p - 1 + 1) n from
        (sub_add_cancel p 1).symm ▸ hu)
  have hdlo : (0 : (K.X (p - 1)).X (q + 1)) =
      ((K.d (p - 1 - 1) (p - 1)).f (q + 1)).hom c +
      (p - 1).negOnePow • vertical K (p - 1) q a := by
    have h := d_projection_apply K (p - 1) (q + 1) (n - 1) (by lia -abstractProof) u
    rw [show n - 1 + 1 = n by lia -abstractProof, show q + 1 - 1 = q by lia -abstractProof, hlo] at h
    exact h
  have hhzero : ((K.d (p - 1) p).f (q + 1)).hom
      (((K.d (p - 1 - 1) (p - 1)).f (q + 1)).hom c) = 0 :=
    congrArg (fun f => f.hom c) (K.d_f_comp_d_f (p - 1 - 1) (p - 1) p (q + 1))
  have hcomm : vertical K p q (((K.d (p - 1) p).f q).hom a) =
      ((K.d (p - 1) p).f (q + 1)).hom (vertical K (p - 1) q a) :=
    congrArg (fun f => f.hom a) (K.d_comm (p - 1) p q (q + 1))
  have hv : vertical K p q (((K.d (p - 1) p).f q).hom a) = 0 :=
    hcomm.trans (reviewer_linear_signed_sum ((K.d (p - 1) p).f (q + 1)).hom
      (((K.d (p - 1 - 1) (p - 1)).f (q + 1)).hom c)
      (vertical K (p - 1) q a) (p - 1).negOnePow hdlo hhzero)
  have hdd' : LinearMap.range ((K.d (p - 1) p).f q).hom ⊓
      LinearMap.ker (vertical K p q) =
      LinearMap.range (((K.d (p - 1) p).f q).hom.comp (incomingVertical K (p - 1) q)) := by
    dsimp only [ImageKernel, horizontal] at hdd
    rw [show p - 1 + 1 = p by lia -abstractProof] at hdd
    exact hdd
  have hm : ((K.d (p - 1) p).f q).hom a ∈
      LinearMap.range ((K.d (p - 1) p).f q).hom ⊓ LinearMap.ker (vertical K p q) :=
    ⟨⟨a, rfl⟩, hv⟩
  match hdd' ▸ hm with
  | ⟨w, hw⟩ =>
    have hc : incomingVertical K p q (((K.d (p - 1) p).f (q - 1)).hom w) =
        ((K.d (p - 1) p).f q).hom (incomingVertical K (p - 1) q w) :=
      congrArg (fun f => f.hom w) (K.d_comm (p - 1) p (q - 1) q)
    ⟨((K.d (p - 1) p).f (q - 1)).hom w + p.negOnePow • b,
      by
        change ((K.d (p - 1) p).f q).hom (incomingVertical K (p - 1) q w) =
          ((K.d (p - 1) p).f q).hom a at hw
        simpa only [map_add, Units.smul_def, map_zsmul, hc, hw] using hd.symm⟩

end AlgebraicHodgePilot.Column
