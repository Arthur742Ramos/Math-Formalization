import ColumnComponents
open AlgebraicHodgePilot
local notation:max "Diff " K:arg n:arg m:arg => ModuleCat.Hom.hom (HomologicalComplex.d (total K) n m)
local notation:max "Comp " K:arg p:arg q:arg => HomologicalComplex.X (HomologicalComplex.X K p) q
variable {k : Type} [Field k] (K : Bicomplex k) (n m p q : ℤ)
#check Diff K n m
#check Comp K p q
#check Column.d_projection K p q n
