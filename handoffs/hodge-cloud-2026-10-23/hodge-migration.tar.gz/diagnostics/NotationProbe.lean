import HodgeChallenge
open AlgebraicHodgePilot
local notation "Comp[" K ";" p "," q "]" => (K.X p).X q
local notation "Tot[" K ";" n "]" => (AlgebraicHodgePilot.total K).X n
#check Column.boundary_leading_exact
